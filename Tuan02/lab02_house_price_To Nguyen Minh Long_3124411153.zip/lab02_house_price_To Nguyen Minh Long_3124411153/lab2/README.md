# Dự đoán giá nhà bằng TensorFlow Decision Forests

Dự án ước lượng giá bán nhà ở thành phố Ames (Iowa) từ 79 đặc trưng mô tả căn nhà:
diện tích, chất lượng hoàn thiện, khu dân cư, năm xây, gara, tầng hầm…

Mô hình sử dụng: rừng ngẫu nhiên trong thư viện TensorFlow Decision Forests. Lý do
chọn mô hình cây là bảng dữ liệu lẫn cột số với cột chữ và có nhiều ô trống — cây
quyết định nhận thẳng dữ liệu thô như vậy, không cần one-hot encoding hay điền giá
trị thiếu.

---

## Cấu trúc thư mục

```
.
├── house-price-prediction.ipynb   # notebook chính: khảo sát, huấn luyện, dự đoán
├── data_description.txt           # giải thích ý nghĩa từng cột
├── train.csv                      # 1460 căn, có cột SalePrice
├── test.csv                       # 1459 căn, cần dự đoán giá
├── sample_submission.csv          # mẫu định dạng file nộp
├── requirements.txt
└── README.md
```

Chạy xong notebook sẽ sinh thêm `submission.csv`.

---

## Cách chạy

1. Cài thư viện:

   ```bash
   pip install -r requirements.txt
   ```

2. Mở notebook:

   ```bash
   jupyter notebook house-price-prediction.ipynb
   ```

3. Chạy lần lượt các cell từ trên xuống. Dữ liệu được đọc trực tiếp từ các file CSV
   trong cùng thư mục, không cần tải thêm gì.

> `tensorflow-decision-forests` chỉ có bản dựng cho Linux và macOS. Trên Windows cần
> chạy qua WSL, hoặc dùng Google Colab.

---

## Các bước trong notebook

| Phần | Nội dung |
|---|---|
| 1–2 | Nạp thư viện, đọc `train.csv` / `test.csv`, bỏ cột `Id` |
| 3 | Phân phối `SalePrice` và `log(SalePrice)` |
| 4 | Tỉ lệ dữ liệu thiếu, phân phối toàn bộ cột số |
| 5 | Tương quan với giá, quan hệ `GrLivArea` và `OverallQual` với giá |
| 6 | Tách 80/20 bằng seed cố định, chuyển sang dataset của TensorFlow |
| 7 | Huấn luyện rừng ngẫu nhiên 300 cây |
| 8 | RMSE out-of-bag, đánh giá trên tập kiểm định (RMSE, RMSLE, MAE, R²) |
| 9 | Độ quan trọng của đặc trưng theo `NUM_AS_ROOT` |
| 10 | Dự đoán tập test, ghi `submission.csv` |

---

## Ghi chú về cách làm

- **Tách dữ liệu có seed cố định.** Dùng `np.random.default_rng(42)` thay vì bốc ngẫu
  nhiên mỗi lần chạy, nhờ vậy các con số đánh giá giữa những lần thử nghiệm mới so
  sánh được với nhau.
- **Không điền giá trị thiếu.** Ở bộ dữ liệu này, ô trống của `PoolQC`, `Fence`,
  `GarageType`… mang nghĩa "căn nhà không có hạng mục đó", nên điền bừa sẽ làm sai
  lệch thông tin. Mô hình cây xử lý được ô trống nên giữ nguyên là hợp lý nhất.
- **Theo dõi RMSLE bên cạnh RMSE.** Giá nhà lệch phải mạnh, RMSE bị nhóm nhà đắt tiền
  chi phối; RMSLE phạt sai số theo tỉ lệ nên phản ánh đúng chất lượng dự đoán ở cả
  phân khúc rẻ lẫn đắt.
- **Giữ lại điểm ngoại lai.** Vài căn diện tích rất lớn nhưng giá thấp bất thường được
  giữ nguyên, vì rừng ngẫu nhiên ít bị chúng kéo lệch.

---

## Kết quả

Điền số liệu sau khi chạy xong notebook:

| Chỉ số (tập kiểm định) | Giá trị |
|---|---|
| RMSE | |
| RMSLE | |
| MAE | |
| R² | |

Đặc trưng ảnh hưởng nhiều nhất: `OverallQual`, `GrLivArea`, `Neighborhood`,
`TotalBsmtSF`.

---

## Hướng phát triển

- Tạo đặc trưng gộp: tổng diện tích sử dụng, tuổi nhà lúc bán, số phòng tắm quy đổi.
- Huấn luyện trên `log(SalePrice)` rồi mũ ngược khi dự đoán.
- So sánh rừng ngẫu nhiên với gradient boosting, hoặc trộn hai mô hình.
- Kiểm định chéo K-fold thay cho một lần tách 80/20.

---

## Nguồn dữ liệu

Bộ dữ liệu nhà ở Ames, Iowa (79 đặc trưng, 1460 mẫu huấn luyện).
